import { invoke } from '@tauri-apps/api/core';

export type NativeAction = 'shutdown' | 'restart' | 'lock' | 'sleep';

export async function executeNativeAction(
  action: NativeAction,
  force: boolean = true
): Promise<void> {
  await invoke('execute_action', { action, force });
}
