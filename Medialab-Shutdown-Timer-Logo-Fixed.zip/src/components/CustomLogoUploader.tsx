import React from 'react';
import logoUrl from '../assets/medialab-publishing.png';

interface CustomLogoUploaderProps {
  isArabic: boolean;
  className?: string;
}

/**
 * Brand protection: always display the supplied original MediaLab Publishing
 * PNG. Do not redraw, recolor, replace, or allow runtime uploads to override it.
 */
export const CustomLogoUploader: React.FC<CustomLogoUploaderProps> = ({ className = '' }) => {
  return (
    <div className={`relative select-none flex items-center ${className}`}>
      <img
        src={logoUrl}
        alt="MediaLab Publishing"
        draggable={false}
        className="block h-auto max-h-12 sm:max-h-13 w-auto max-w-[170px] object-contain pointer-events-none"
      />
    </div>
  );
};
