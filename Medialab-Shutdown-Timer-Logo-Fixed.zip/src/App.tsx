import React, { useState, useEffect, useRef } from 'react';
import { 
  RotateCcw, 
  ArrowDown,
  Clock,
  Zap,
  Volume2,
  VolumeX
} from 'lucide-react';
import { sounds } from './utils/audio';
import { ShutdownConfig } from './utils/scripts';
import { ExportExeModal } from './components/ExportExeModal';
import { CustomLogoUploader } from './components/CustomLogoUploader';
import { executeNativeAction } from './utils/native';

type ActionType = 'shutdown' | 'restart' | 'lock' | 'sleep';

export default function App() {
  // Localization: English (default) or Arabic
  const [isArabic, setIsArabic] = useState<boolean>(false);
  
  // Direct editable time units (Hours, Minutes, Seconds) as fluid strings
  const [hoursStr, setHoursStr] = useState<string>('00');
  const [minutesStr, setMinutesStr] = useState<string>('00');
  const [secondsStr, setSecondsStr] = useState<string>('00');

  const timerHours = parseInt(hoursStr, 10) || 0;
  const timerMinutes = parseInt(minutesStr, 10) || 0;
  const timerSeconds = parseInt(secondsStr, 10) || 0;
  const configuredTotalSecs = (timerHours * 3600) + (timerMinutes * 60) + timerSeconds;
  
  // Timer Configuration
  const [actionType, setActionType] = useState<ActionType>('shutdown');
  const [forceKill, setForceKill] = useState<boolean>(true);
  const [warningSound, setWarningSound] = useState<boolean>(true);
  const [pinProtected, setPinProtected] = useState<boolean>(false);
  const [pinCode, setPinCode] = useState<string>('1234');
  
  // Running State
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [totalSeconds, setTotalSeconds] = useState<number>(0);
  const [remainingSeconds, setRemainingSeconds] = useState<number>(0);
  
  // Modals
  const [isExportModalOpen, setIsExportModalOpen] = useState<boolean>(false);

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const handleApplyPreset = (h: number, m: number, s: number) => {
    if (isRunning) return;
    sounds.playClick();
    setHoursStr(h.toString().padStart(2, '0'));
    setMinutesStr(m.toString().padStart(2, '0'));
    setSecondsStr(s.toString().padStart(2, '0'));
  };

  useEffect(() => {
    if (isRunning && remainingSeconds > 0) {
      timerRef.current = setInterval(() => {
        setRemainingSeconds((prev) => {
          if (prev <= 1) {
            clearInterval(timerRef.current!);
            setIsRunning(false);
            sounds.playAlarm();
            executeNativeAction(actionType, forceKill).catch((error) => {
              console.error('Windows action failed:', error);
            });
            return 0;
          }
          if (prev === 61 && warningSound) {
            sounds.playAlarm();
          } else if (prev <= 5 && warningSound) {
            sounds.playTick();
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isRunning, remainingSeconds, warningSound, actionType, forceKill]);

  const handleToggleTimer = () => {
    if (isRunning) {
      sounds.playCancel();
      setIsRunning(false);
    } else {
      const configuredTotal = (timerHours * 3600) + (timerMinutes * 60) + timerSeconds;
      if (configuredTotal <= 0) return;
      // Normalize strings to clean 2-digit format on start
      setHoursStr(timerHours.toString().padStart(2, '0'));
      setMinutesStr(timerMinutes.toString().padStart(2, '0'));
      setSecondsStr(timerSeconds.toString().padStart(2, '0'));
      setTotalSeconds(configuredTotal);
      setRemainingSeconds(configuredTotal);
      setIsRunning(true);
      sounds.playStart();
    }
  };

  // Active display calculation
  const activeDisplaySeconds = isRunning ? remainingSeconds : configuredTotalSecs;
  
  const displayHours = isRunning 
    ? Math.floor(remainingSeconds / 3600).toString().padStart(2, '0') 
    : hoursStr;
  const displayMinutes = isRunning 
    ? Math.floor((remainingSeconds % 3600) / 60).toString().padStart(2, '0') 
    : minutesStr;
  const displaySeconds = isRunning 
    ? (remainingSeconds % 60).toString().padStart(2, '0') 
    : secondsStr;

  const progressPercent = totalSeconds > 0 
    ? Math.min(100, Math.max(0, ((totalSeconds - remainingSeconds) / totalSeconds) * 100))
    : 0;

  const getTargetTimeStr = () => {
    if (activeDisplaySeconds <= 0) return isArabic ? 'حدد الوقت أولاً' : 'Select Time First';
    const targetDate = new Date(Date.now() + activeDisplaySeconds * 1000);
    return targetDate.toLocaleTimeString(isArabic ? 'ar-EG' : 'en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    });
  };

  const actionName = {
    shutdown: isArabic ? 'إغلاق إجباري' : 'Force Shutdown',
    restart: isArabic ? 'إعادة تشغيل' : 'Restart PC',
    lock: isArabic ? 'قفل الشاشة' : 'Lock Screen',
    sleep: isArabic ? 'سكون تام' : 'Sleep Mode'
  }[actionType];

  const currentConfig: ShutdownConfig = {
    action: actionType,
    totalSeconds: isRunning ? remainingSeconds : configuredTotalSecs,
    forceKill,
    warningSound,
    pinProtected,
    pinCode,
  };

  return (
    <div 
      className="min-h-screen bg-[#ece9e2] text-[#222] flex flex-col justify-center items-center p-3 sm:p-6 font-sans select-none"
      dir={isArabic ? 'rtl' : 'ltr'}
    >
      
      {/* Main Desktop Card Frame */}
      <div 
        className="w-full max-w-[530px] bg-[#f4f2ee] rounded-2xl shadow-xl border border-neutral-300/80 overflow-hidden p-6 sm:p-8 space-y-6"
      >
          
            {/* Header Row: Custom Logo Uploader ALWAYS on left, Language & Sound ALWAYS on right */}
            <div className="flex items-center justify-between gap-4" dir="ltr">
              <CustomLogoUploader isArabic={isArabic} />
            
            <div className="flex flex-col items-end gap-1.5" dir="ltr">
              <div className="flex items-center gap-1.5">
                {/* Sound Toggle (قفل / تشغيل الصوت) */}
                <button
                  type="button"
                  onClick={() => {
                    const next = !warningSound;
                    setWarningSound(next);
                    sounds.enabled = next;
                    if (next) sounds.playClick();
                  }}
                  className={`p-1.5 rounded-lg border transition-all cursor-pointer flex items-center justify-center ${
                    warningSound
                      ? 'bg-[#ece9e2] border-neutral-300/80 text-neutral-700 hover:text-neutral-900 hover:bg-[#e3dfd6]'
                      : 'bg-red-50 border-red-200 text-red-500 hover:bg-red-100'
                  }`}
                  title={isArabic ? (warningSound ? 'كتم الصوت' : 'تشغيل الصوت') : (warningSound ? 'Mute sound' : 'Unmute sound')}
                >
                  {warningSound ? (
                    <Volume2 className="w-4 h-4" />
                  ) : (
                    <VolumeX className="w-4 h-4" />
                  )}
                </button>

                {/* Language Switcher [ English | عربي ] */}
                <div className="flex items-center bg-[#ece9e2] p-1 rounded-lg border border-neutral-300/70 text-xs font-semibold shadow-2xs">
                  <button
                    type="button"
                    onClick={() => {
                      sounds.playClick();
                      setIsArabic(false);
                    }}
                    className={`px-2.5 py-1 rounded-md transition-all cursor-pointer ${
                      !isArabic 
                        ? 'bg-white text-neutral-900 shadow-xs font-bold' 
                        : 'text-neutral-500 hover:text-neutral-800'
                    }`}
                    title="English (Default)"
                  >
                    English
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      sounds.playClick();
                      setIsArabic(true);
                    }}
                    className={`px-2.5 py-1 rounded-md transition-all cursor-pointer ${
                      isArabic 
                        ? 'bg-white text-neutral-900 shadow-xs font-bold' 
                        : 'text-neutral-500 hover:text-neutral-800'
                    }`}
                    title="التبديل إلى اللغة العربية"
                  >
                    عربي
                  </button>
                </div>
              </div>

              {/* Category Subtitle */}
              <div className="text-[11px] font-bold text-neutral-400 tracking-wider uppercase">
                {isArabic ? 'مؤقت الإغلاق والقفل' : 'SHUTDOWN TIMER'}
              </div>
            </div>
          </div>

          {/* PRIMARY MAIN TIMER: Professional Digital Countdown Hub & Direct Controller */}
          <div className="bg-white rounded-2xl border border-neutral-200/90 p-5 shadow-sm space-y-4">
            
            {/* Top Bar: Live Status Badge + Real-World Target Execution Time */}
            <div className="flex items-center justify-between text-xs">
              {/* Status Badge */}
              <div className="flex items-center gap-2">
                {isRunning ? (
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold bg-orange-50 text-[#e85933] border border-orange-200">
                    <span className="relative flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#e85933] opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-[#e85933]"></span>
                    </span>
                    <span>{isArabic ? 'جاري العد التنازلي' : 'Active Countdown'}</span>
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold bg-neutral-100 text-neutral-600 border border-neutral-200">
                    <span className="w-2 h-2 rounded-full bg-neutral-400"></span>
                    <span>{isArabic ? 'في وضع الاستعداد' : 'Standby Mode'}</span>
                  </span>
                )}
              </div>

              {/* Target Clock Time */}
              <div className="flex items-center gap-1.5 text-neutral-500 font-semibold text-[11px]">
                <Clock className="w-3.5 h-3.5 text-neutral-400" />
                <span>
                  {isArabic ? 'موعد التنفيذ:' : 'Target Time:'}{' '}
                  <strong className="text-neutral-800 font-mono font-bold">{getTargetTimeStr()}</strong>
                </span>
              </div>
            </div>

            {/* CLEAN DIRECT EDITABLE DIGITAL CHRONO BLOCKS: [ HRS ] : [ MIN ] : [ SEC ] */}
            <div className="flex items-center justify-center gap-2 sm:gap-4 py-2 font-mono select-none" dir="ltr">
              
              {/* Hours Block */}
              <div className="flex flex-col items-center">
                <input
                  type="text"
                  inputMode="numeric"
                  maxLength={2}
                  disabled={isRunning}
                  value={displayHours}
                  onFocus={(e) => e.target.select()}
                  onChange={(e) => {
                    const cleaned = e.target.value.replace(/\D/g, '').slice(0, 2);
                    setHoursStr(cleaned);
                  }}
                  onBlur={() => {
                    const num = parseInt(hoursStr, 10);
                    const clamped = isNaN(num) ? 0 : Math.min(99, Math.max(0, num));
                    setHoursStr(clamped.toString().padStart(2, '0'));
                  }}
                  className="w-20 sm:w-24 py-3 sm:py-3.5 bg-[#f4f2ee] text-neutral-900 rounded-2xl border border-neutral-300/80 text-center font-bold text-3xl sm:text-4xl shadow-inner font-mono tracking-wider focus:outline-none focus:border-[#e85933] focus:bg-white transition-all disabled:bg-[#f4f2ee] disabled:text-neutral-900 cursor-text select-all"
                />
                <span className="text-[11px] font-bold text-neutral-400 mt-2 uppercase tracking-wider">
                  {isArabic ? 'ساعة' : 'HRS'}
                </span>
              </div>

              <span className="text-3xl font-bold text-neutral-300 -mt-6 animate-pulse select-none">:</span>

              {/* Minutes Block */}
              <div className="flex flex-col items-center">
                <input
                  type="text"
                  inputMode="numeric"
                  maxLength={2}
                  disabled={isRunning}
                  value={displayMinutes}
                  onFocus={(e) => e.target.select()}
                  onChange={(e) => {
                    const cleaned = e.target.value.replace(/\D/g, '').slice(0, 2);
                    const num = parseInt(cleaned, 10);
                    if (!isNaN(num) && num > 59) {
                      setMinutesStr('59');
                    } else {
                      setMinutesStr(cleaned);
                    }
                  }}
                  onBlur={() => {
                    const num = parseInt(minutesStr, 10);
                    const clamped = isNaN(num) ? 0 : Math.min(59, Math.max(0, num));
                    setMinutesStr(clamped.toString().padStart(2, '0'));
                  }}
                  className="w-20 sm:w-24 py-3 sm:py-3.5 bg-[#f4f2ee] text-neutral-900 rounded-2xl border border-neutral-300/80 text-center font-bold text-3xl sm:text-4xl shadow-inner font-mono tracking-wider focus:outline-none focus:border-[#e85933] focus:bg-white transition-all disabled:bg-[#f4f2ee] disabled:text-neutral-900 cursor-text select-all"
                />
                <span className="text-[11px] font-bold text-neutral-400 mt-2 uppercase tracking-wider">
                  {isArabic ? 'دقيقة' : 'MIN'}
                </span>
              </div>

              <span className="text-3xl font-bold text-neutral-300 -mt-6 animate-pulse select-none">:</span>

              {/* Seconds Block */}
              <div className="flex flex-col items-center">
                <input
                  type="text"
                  inputMode="numeric"
                  maxLength={2}
                  disabled={isRunning}
                  value={displaySeconds}
                  onFocus={(e) => e.target.select()}
                  onChange={(e) => {
                    const cleaned = e.target.value.replace(/\D/g, '').slice(0, 2);
                    const num = parseInt(cleaned, 10);
                    if (!isNaN(num) && num > 59) {
                      setSecondsStr('59');
                    } else {
                      setSecondsStr(cleaned);
                    }
                  }}
                  onBlur={() => {
                    const num = parseInt(secondsStr, 10);
                    const clamped = isNaN(num) ? 0 : Math.min(59, Math.max(0, num));
                    setSecondsStr(clamped.toString().padStart(2, '0'));
                  }}
                  className={`w-20 sm:w-24 py-3 sm:py-3.5 rounded-2xl border text-center font-bold text-3xl sm:text-4xl shadow-inner font-mono tracking-wider focus:outline-none transition-all cursor-text select-all ${
                    isRunning 
                      ? 'bg-orange-50 text-[#e85933] border-orange-300/80 disabled:bg-orange-50 disabled:text-[#e85933]' 
                      : 'bg-[#f4f2ee] text-neutral-900 border-neutral-300/80 focus:border-[#e85933] focus:bg-white'
                  }`}
                />
                <span className="text-[11px] font-bold text-neutral-400 mt-2 uppercase tracking-wider">
                  {isArabic ? 'ثانية' : 'SEC'}
                </span>
              </div>
            </div>

            {/* Quick Presets Underneath Digital Clock */}
            {!isRunning && (
              <div className="flex items-center justify-center gap-1.5 flex-wrap pt-2 border-t border-neutral-100">
                <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider">
                  {isArabic ? 'تحديد سريع:' : 'Presets:'}
                </span>
                {[
                  { label: isArabic ? '15 د' : '15m', h: 0, m: 15, s: 0 },
                  { label: isArabic ? '30 د' : '30m', h: 0, m: 30, s: 0 },
                  { label: isArabic ? '45 د' : '45m', h: 0, m: 45, s: 0 },
                  { label: isArabic ? '1 س' : '1h', h: 1, m: 0, s: 0 },
                  { label: isArabic ? '2 س' : '2h', h: 2, m: 0, s: 0 },
                  { label: isArabic ? '3 س' : '3h', h: 3, m: 0, s: 0 },
                ].map((preset) => {
                  const isSelected = timerHours === preset.h && timerMinutes === preset.m && timerSeconds === preset.s;
                  return (
                    <button
                      key={preset.label}
                      type="button"
                      onClick={() => handleApplyPreset(preset.h, preset.m, preset.s)}
                      className={`px-2.5 py-1 rounded-md text-xs font-bold border transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-[#e85933] text-white border-[#e85933] shadow-xs'
                          : 'bg-[#f4f2ee] text-neutral-700 border-neutral-300 hover:bg-neutral-200'
                      }`}
                    >
                      {preset.label}
                    </button>
                  );
                })}
              </div>
            )}

            {/* Precision Progress Bar with Scheduled Action & Percentage */}
            <div className="space-y-1.5 pt-1">
              <div className="flex items-center justify-between text-xs font-semibold text-neutral-500">
                <div className="flex items-center gap-1.5">
                  <Zap className="w-3.5 h-3.5 text-[#e85933]" />
                  <span>
                    {isArabic ? 'الإجراء المجدول:' : 'Scheduled:'}{' '}
                    <span className="text-neutral-900 font-bold">{actionName}</span>
                  </span>
                </div>
                <span className="font-mono text-xs font-bold text-neutral-700">
                  {Math.round(progressPercent)}%
                </span>
              </div>

              {/* Progress track */}
              <div className="relative w-full h-2 bg-[#ece9e2] rounded-full overflow-hidden p-0.5 border border-neutral-300/60" dir="ltr">
                <div 
                  className="h-full bg-gradient-to-r from-[#e85933] via-[#ff6e40] to-[#e85933] rounded-full transition-all duration-300 shadow-xs"
                  style={{ width: `${isRunning ? Math.max(3, progressPercent) : (progressPercent > 0 ? progressPercent : 2)}%` }}
                />
              </div>
            </div>

          </div>

          {/* Row 2: ACTION TYPE */}
          <div className="space-y-1.5">
            <div className="text-[11px] font-bold text-neutral-400 tracking-wider uppercase">
              {isArabic ? 'نوع الإجراء' : 'ACTION TYPE'}
            </div>
            <div className="grid grid-cols-4 gap-2">
              {[
                { id: 'shutdown' as ActionType, ar: 'إغلاق إجباري', en: 'Shutdown' },
                { id: 'restart' as ActionType, ar: 'إعادة تشغيل', en: 'Restart' },
                { id: 'lock' as ActionType, ar: 'قفل الشاشة', en: 'Lock' },
                { id: 'sleep' as ActionType, ar: 'سكون تام', en: 'Sleep' },
              ].map((opt) => {
                const isSelected = actionType === opt.id;
                return (
                  <button
                    key={opt.id}
                    type="button"
                    disabled={isRunning}
                    onClick={() => {
                      sounds.playClick();
                      setActionType(opt.id);
                    }}
                    className={`py-2 px-1 rounded-lg text-xs font-bold transition-all text-center cursor-pointer disabled:opacity-60 ${
                      isSelected
                        ? 'bg-[#e85933] text-white shadow-sm'
                        : 'bg-white border border-neutral-300 text-neutral-700 hover:bg-neutral-50 shadow-xs'
                    }`}
                  >
                    <span>{isArabic ? opt.ar : opt.en}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Big Orange Action Button */}
          <div className="pt-1">
            <button
              type="button"
              onClick={handleToggleTimer}
              className={`w-full py-3.5 px-6 rounded-lg font-bold text-base flex items-center justify-center gap-2 text-white shadow-sm transition-all cursor-pointer active:scale-[0.99] ${
                isRunning
                  ? 'bg-neutral-800 hover:bg-neutral-900'
                  : 'bg-[#e85933] hover:bg-[#d54924]'
              }`}
            >
              {isRunning ? (
                <>
                  <RotateCcw className="w-4 h-4 text-red-400" />
                  <span>{isArabic ? 'إلغاء المؤقت' : 'Abort Timer'}</span>
                </>
              ) : (
                <>
                  <ArrowDown className="w-4 h-4" />
                  <span>{isArabic ? 'بدء المؤقت' : 'Start Timer'}</span>
                </>
              )}
            </button>
          </div>

      </div>



      {/* Export EXE Modal */}
      <ExportExeModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        config={currentConfig}
        isArabic={isArabic}
      />

    </div>
  );
}
